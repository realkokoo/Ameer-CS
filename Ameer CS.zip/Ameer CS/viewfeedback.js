document.addEventListener('DOMContentLoaded', function() {
    const feedbackContainer = document.getElementById('feedbackContainer');
    loadFeedbacks();

    function loadFeedbacks() {
        feedbackContainer.innerHTML = '';
        const feedbacks = JSON.parse(localStorage.getItem('feedbacks')) || [];

        if (feedbacks.length === 0) {
            feedbackContainer.innerHTML = '<p>There is no feedback yet.</p>';
        } else {
            feedbacks.forEach((feedback, index) => {
                const feedbackDiv = document.createElement('div');
                feedbackDiv.className = 'feedback';
                feedbackDiv.innerHTML = `
                    <h3>${feedback.subject}</h3>
                    <p>${feedback.feedback}</p>
                    <small>Submitted on: ${feedback.date}</small>
                    <button onclick="deleteFeedback(${index})">Delete</button>
                `;
                feedbackContainer.appendChild(feedbackDiv);
            });
        }
    }

    window.deleteFeedback = function(index) {
        let feedbacks = JSON.parse(localStorage.getItem('feedbacks')) || [];
        feedbacks.splice(index, 1);
        localStorage.setItem('feedbacks', JSON.stringify(feedbacks));
        loadFeedbacks(); 
    }
});
