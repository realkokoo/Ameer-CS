
function navigateTo(url) {
    location.href = url;
}
