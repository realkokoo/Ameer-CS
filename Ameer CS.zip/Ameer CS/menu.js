function getNextFiveDays(startDay) {
    let result = [];
    for (let i = 0; result.length < 5; i++) {
        let dayIndex = (startDay.getDay() + i) % 7;
        if (dayIndex !== 5 && dayIndex !== 6) {
            let day = new Date(startDay);
            day.setDate(startDay.getDate() + i);
            result.push(day);
        }
    }
    return result;
}

function formatMenuDate(date) {
    return date.toISOString().split('T')[0];
}

function createMenuTable(startDay) {
    let days = getNextFiveDays(startDay);
    let table = document.createElement('table');
    let thead = table.createTHead();
    let headerRow = thead.insertRow();


    days.forEach(day => {
        let th = document.createElement('th');
        th.innerText = day.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
        headerRow.appendChild(th);
    });

    let tbody = table.createTBody();
    for (let i = 0; i < 8; i++) { 
        let row = tbody.insertRow();
        days.forEach(day => {
            let cell = row.insertCell();
            let formattedDate = formatMenuDate(day);
            let menuItems = JSON.parse(localStorage.getItem('menu_' + formattedDate)) || [];
            cell.innerText = menuItems[i] || '';
        });
    }

    return table;
}

document.addEventListener('DOMContentLoaded', function() {
    let today = new Date();
    let nextWeek = new Date();
    nextWeek.setDate(today.getDate() + 7);
    let weekAfterNext = new Date();
    weekAfterNext.setDate(today.getDate() + 14);

    document.body.appendChild(createMenuTable(today));
    document.body.appendChild(document.createElement('hr'));
    document.body.appendChild(createMenuTable(nextWeek));
    document.body.appendChild(document.createElement('hr'));
    document.body.appendChild(createMenuTable(weekAfterNext));
});
