document.addEventListener('DOMContentLoaded', function() {
    const feedbackForm = document.getElementById('feedbackForm');

    feedbackForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const subject = document.getElementById('subject').value;
        const feedback = document.getElementById('feedback').value;
        const currentDate = new Date();
        const formattedDate = currentDate.toISOString().split('T')[0]; 

        const feedbackData = { subject, feedback, date: formattedDate };

        const feedbacks = JSON.parse(localStorage.getItem('feedbacks')) || [];
        feedbacks.push(feedbackData);

        localStorage.setItem('feedbacks', JSON.stringify(feedbacks));

        alert('Feedback submitted successfully!');
        feedbackForm.reset();
    });
});
