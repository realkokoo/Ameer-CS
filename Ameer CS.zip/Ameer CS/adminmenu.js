document.addEventListener('DOMContentLoaded', function() {
    loadMenuItems();
});

function loadMenuItems() {
    const menuContainer = document.getElementById('menuContainer');
    menuContainer.innerHTML = '';

    for (let tableIndex = 0; tableIndex < 3; tableIndex++) {
        const table = document.createElement('table');
        const thead = document.createElement('thead');
        const tbody = document.createElement('tbody');
        table.appendChild(thead);
        table.appendChild(tbody);

        const dateRow = document.createElement('tr');
        const editButtonsRow = document.createElement('tr');
        thead.appendChild(dateRow);
        thead.appendChild(editButtonsRow);

        for (let i = 0; i < 5; i++) {
            const dayIndex = tableIndex * 5 + i;
            const date = new Date();
            date.setDate(date.getDate() + dayIndex);
            const formattedDate = formatDate(date);
            const menuKey = 'menu_' + formattedDate;

            const dayMenu = JSON.parse(localStorage.getItem(menuKey)) || ['Menu Item 1', 'Menu Item 2', 'Menu Item 3', 'Menu Item 4', 'Menu Item 5', 'Menu Item 6', 'Menu Item 7', 'Menu Item 8'];

            const dateHeader = document.createElement('th');
            dateHeader.textContent = formattedDate;
            dateRow.appendChild(dateHeader);

            const buttonContainer = createEditButton(formattedDate, dayMenu);
            const editCell = document.createElement('th');
            editCell.appendChild(buttonContainer);
            editButtonsRow.appendChild(editCell);

            populateMenuColumns(dayMenu, tbody, i);
        }

        menuContainer.appendChild(table);
    }
}

function formatDate(date) {
    return date.toISOString().split('T')[0];
}

function createEditButton(date, dayMenu) {
    const editButton = document.createElement('button');
    editButton.textContent = 'Edit';
    editButton.className = 'edit-btn';
    editButton.onclick = function() { editMenu(date, dayMenu); };

    const removeButton = document.createElement('button');
    removeButton.textContent = 'Remove';
    removeButton.className = 'remove-btn';
    removeButton.onclick = function() { removeMenu(date, dayMenu); };

    const buttonContainer = document.createElement('div');
    buttonContainer.appendChild(editButton);
    buttonContainer.appendChild(removeButton);

    return buttonContainer;
}

function populateMenuColumns(dayMenu, tbody, columnIndex) {
    dayMenu.forEach((item, index) => {
        if (tbody.rows[index] === undefined) {
            tbody.insertRow(index);
        }
        const cell = tbody.rows[index].insertCell(columnIndex);
        cell.textContent = item;
    });
}

function editMenu(date, dayMenu) {
    localStorage.setItem('editDate', date);
    localStorage.setItem('editMenuItems', JSON.stringify(dayMenu));
    window.location.href = 'editmenu.html';
}

function removeMenu(date, dayMenu) {
    const formattedDate = formatDate(new Date(date));
    const menuKey = 'menu_' + formattedDate;

    localStorage.removeItem(menuKey);
    loadMenuItems();
}
