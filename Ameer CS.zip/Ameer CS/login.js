function checkLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (username === "Ameer" && password === "ameer1254") {
        location.href = 'admin.html'; 
    } else {
        alert("Invalid Credentials");
    }
}
