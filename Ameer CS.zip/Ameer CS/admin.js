document.addEventListener('DOMContentLoaded', function() {
    var greetingText = document.getElementById('greeting');
    var now = new Date();
    var hour = now.getHours();

    if (hour < 12) {
        greetingText.innerText = 'Good Morning';
    } else if (hour < 18) {
        greetingText.innerText = 'Good Afternoon';
    } else {
        greetingText.innerText = 'Good Evening';
    }
});
