document.addEventListener('DOMContentLoaded', function() {
    const editDate = localStorage.getItem('editDate');
    const editMenuItems = JSON.parse(localStorage.getItem('editMenuItems'));

    if (editDate && editMenuItems) {
        document.getElementById('menuDate').value = editDate;

        editMenuItems.forEach((item, index) => {
            const menuItemInput = document.getElementById('menuItem' + (index + 1));
            if (menuItemInput) {
                menuItemInput.value = item;
            }
        });

        localStorage.removeItem('editDate');
        localStorage.removeItem('editMenuItems');
    }


});

function saveMenu() {
    let date = document.getElementById("menuDate").value;
    let menuItems = [];

    for (let i = 1; i <= 8; i++) {
        let itemValue = document.getElementById("menuItem" + i).value;
        menuItems.push(itemValue);

    if (date) {
        localStorage.setItem('menu_' + date, JSON.stringify(menuItems));
        alert('Menu saved for ' + date + '!');
        window.location.href = 'admin.html';
    } else {
        alert('Please select a date.');
    }
}
